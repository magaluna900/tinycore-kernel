## PeppyScreensaver
PeppyMeter as screensaver for Volumio on raspberry pi
>Many thanks to peppy.player, who provided the conditions for this

-----
##### Version: 1.3.0

* add resolution 1280x720

##### Version: 1.2.0

* add resolution 1920x 480
* prepare the plugin to allow a volumio system update if the plugin deactivated

##### Version 1.0.0

* initial version

 
